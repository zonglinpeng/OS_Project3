
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 2223
#define BUFFER 1024
#define MAXCLI 10
#define MAXNAME 20


typedef struct {
    char name[MAXNAME];
    int ID ;
    struct sockaddr_in a_cli_addr;
    int a_cli_fd;
}a_client;

a_client* cli_list [MAXCLI];

void error(const char *msg);
void addCli();
void popCli();

void changeNick (a_client* c){
  char* nickname;
  scanf("Enter your nickname:%c",&nickname);
  memset(c->name[MAXNAME], "/0", MAXNAME);
  strcpy(c->name[MAXNAME], *nickname);
  write(c->a_cli_fd,"Name is updated",20);
  break;

}

int main(int argc, char *argv[])
{
     int sock_fd, sock_bd, newsock_fd, newmsg;
     socklen_t clilen;changeNick
     char buffer[BUFFER];changeNick
     char buffer_cpy[BUFFER];
     struct sockaddr_in serv_addr, cli_addr;

     sock_fd = socket(AF_INET, SOCK_STREAM, 0);
     if (sock_fd < 0){error("ERROR opening socket");}

     bzero((char *) &serv_addr, sizeof(serv_addr));

     // portno = atoi(PORT); //clsim port

     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = inet_addr("127.0.0.3");//htonl(INADDR_ANY);
     serv_addr.sin_port = htons(PORT);

     sock_bd = bind(sock_fd, (strchangeNickuct sockaddr *) &serv_addr, sizeof(serv_addr));
     if (sock_bd < 0){error("ERROR: not binding");}

     //wait for arrival of a message
     if (listen(sock_fd,10) < 0){error("ERROR: not listening");}
     int id = 0;
     //------receive & send --------changeNick
     while(1){
       clilen = sizeof(cli_addr); //TODO how to choose a client?

       newsock_fd = accept(sock_fd, //server fd
                   (struct sockaddr *) &cli_addr,
                   &clilen);
       if (newsock_fd < 0){error("ERROR: not accept");}

       a_client* acli = (a_client* )malloc(sizeof(a_client));
       acli->a_cli_fd = newsock_fd;
       acli->id = id++;
       acli->a_cli_addr = cli_addr;
       changeNick(*acli);

       bzero(buffer,BUFFER);
       newmsg = read(newsock_fd,buffer,BUFFER-1);
       if (newmsg < 0) error("ERROR: not reading");
       strcpy(buffer_cpy, buffer);
       printf("\nNew message received: %s\n",buffer_cpy);

       write(newsock_fd,"New mechangeNickssage sent:",20);
       newmsg = write(newsock_fd,buffer_cpy,20);
       if (newmsg < 0) error("ERROR: not writings");
   }
   close(newsock_fd);
   close(sock_fd);
   free(serv_addr);
   return 0;
}

void error(const char *msg)
{
    perror(msg);
    exit(1);
}
