#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>

#define BUFFER 1024
#define PORT 2223



void error(const char *msg);

int main(int argc, char *argv[])
{
	int sock_fd, sock_cn, newmsg;
	struct sockaddr_in serv_addr;
	struct hostent *server; //TODO server type hostent

	char buffer[BUFFER];

	//initialize and get socket
	sock_fd = socket(AF_INET, SOCK_STREAM, 0);//file descriptor for client
	if (sock_fd < 0){ error("ERROR: opening socket");}
	else{printf("SUCCESS: connected to server");}

	//initialize and get server
	/*
    server = gethostbyname(argv[1]); //TODO server type hostent
    if (server == NULL) {
        error("ERROR: no such host\n");
    }else{printf("SUCCESS: host is found");}
	 */

	//initialize server address with 0
	bzero(&serv_addr, sizeof(serv_addr));

	//assign server address struct
	serv_addr.sin_family = AF_INET;
	/*
    bcopy((char *)server->h_addr,
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
	 */
  inet_pton(AF_INET, "127.0.0.3", &serv_addr.sin_addr.s_addr );
	serv_addr.sin_port = htons(PORT);

  //connect client with server
	sock_cn = connect(sock_fd,
			(struct sockaddr *) &serv_addr, //server get client addr here
			sizeof(serv_addr));
	//check if connected or not
	if (sock_cn < 0) {error("ERROR: not yet connected");}

	//------start send and receive-------
	while(1){
		printf("\nEnter a message: ");

		//initialze buffer
		bzero(buffer,BUFFER);

		//get the written message from the buffer
		fgets(buffer,BUFFER-1,stdin);
		newmsg = write(sock_fd,buffer,strlen(buffer));
		if (newmsg < 0){error("ERROR: writing failed");}

		bzero(buffer,BUFFER); //initialize buffer
		newmsg = read(sock_fd,buffer,BUFFER);
		if (newmsg < 0){error("ERROR: reading fail");}

		printf("%s\n",buffer);
	}
  close(sock_fd);
  return 0;
}

void error(const char *msg)
{
	perror(msg);
	exit(0);
}
